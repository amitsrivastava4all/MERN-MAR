import logo from './logo.svg';
import './App.css';
import { ProductList } from './components/ProductList';
import { AddFun } from './hoc/AddFun';

function App() {
  const ProductListWithSearch = AddFun(ProductList);
  return (
      <ProductListWithSearch/>
  );
}

export default App;
