import { useRef, useState } from "react";

export const AddFun =(WrappedComponent)=>{
    const searchVal = useRef('');
    const [val, setVal] = useState('');
    const searchIt = ()=>{
        setVal(searchVal.current.value);
    }
    const ListWithSearch = ()=>
            (<div>
            <h1>Search Product</h1>
            <input ref ={searchVal}  type='text' placeholder="Type to Search Here "/>
            <button onClick={searchIt}>Search</button>
            <WrappedComponent searchval = {val}/>

    </div>);
    return ListWithSearch;
}