export const ProductList = ({searchval})=>{
    let products = ['Apple', 'Samsung', 'Motorola'];
    if(searchval.length>0){
        products = products.filter(product=>product.includes(searchval));
    }
    return (<div>
        {products.map(product=>{
            return <p>{product}</p>
        })}
    </div>)
}