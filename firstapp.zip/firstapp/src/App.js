// I am the Root Component
export const App = ()=>{
  return (<h1>Hello React JS </h1>)
}