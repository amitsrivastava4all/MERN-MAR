// Map Component to the HTML
// VDOM --> DOM
import ReactDOM from 'react-dom';
import { App } from './App';
const root = ReactDOM.createRoot(document.querySelector('#root'));
root.render(<App/>);