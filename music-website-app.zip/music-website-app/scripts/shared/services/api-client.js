// BackEnd API Call
import { URLS } from "../config/constants.js";
export const apiClient = {
    get(){
        const promise = fetch(URLS.SINGER_URL);
        return promise;
    },
    post(){

    }
}