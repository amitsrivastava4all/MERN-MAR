export const URLS = {
    SINGER_URL : 'https://raw.githubusercontent.com/brainmentorspvtltd/myserverdata/master/singers.json'
}