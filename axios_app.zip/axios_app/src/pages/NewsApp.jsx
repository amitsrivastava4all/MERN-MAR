import { useEffect } from "react"
import { ApiClient } from "../services/api-client"
import { useState } from "react"
import { News } from "../components/News";

export const NewsApp = ()=>{
    const [headLines, setHeadLines]= useState([]);
    const [error, setError]= useState(null);
    const apiClient = new ApiClient();
    const getMusic = ()=>{
        apiClient.getMusic();
    }

    const getHeadLines =async ()=>{
        
        try{
        const headLinesArr = await apiClient.getHeadLines();
        console.log('HeadLines in Component ', headLinesArr);
        setHeadLines(headLinesArr);
        }
        catch(err){
            setError(err);
            console.error('Not Getting Headlines Error ::: ', err);
        }
    }
    useEffect(()=>{
        getHeadLines();
        getMusic();
    },[])
    return (<div className = 'container'>
        <h1 className='alert alert-info text-center'>News App</h1>
        {error?<p>Error Occur in Fetching News </p>
        :headLines.map((news, index)=><News key={index} news = {news}/>)}
    </div>)
}