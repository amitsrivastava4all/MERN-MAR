export const News = ({news})=>{
    const myStyle = {
        width:'100px',
        height:'100px'
    }
    return (<div>
        <img style={myStyle} src={news.urlToImage}/>
        <p>{news.title}</p>
    </div>)
}