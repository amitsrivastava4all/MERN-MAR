import logo from './logo.svg';
import './App.css';
import { NewsApp } from './pages/NewsApp';

function App() {
  return (
    <NewsApp/>
  );
}

export default App;
