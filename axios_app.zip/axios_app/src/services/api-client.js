import axios from 'axios';
axios.defaults.baseURL=process.env.REACT_APP_NEWS_BASE_URL;
//axios.defaults.headers={'token':'A123'}

axios.defaults.timeout=1000 

const axiosObject = axios.create({
    baseURL:'https://itunes.apple.com',
    timeout:3000
})
export class ApiClient{
    async getHeadLines(){
        // ?country=in&apiKey=11f0dc28d8874be0bb82287cbcf26121
        // /country/in
        // const response = axios.get(process.env.REACT_APP_HEADLINES,{
        //     params:{
        //         country:'in',
        //         apiKey:'11f0dc28d8874be0bb82287cbcf26121'
        //     }
        // })

        const response = await axios.get(process.env.REACT_APP_HEADLINES+"?country=in&apiKey=11f0dc28d8874be0bb82287cbcf26121");
        console.log('Response is ', response);
        return response.data.articles;
    }
    async getMusic(){
        const response = await axiosObject.get(process.env.REACT_APP_MUSICURL);
        console.log('Music Response ',response); 
    }
    getNews(){

    }
    getSportNews(){

    }
    postNews(){
        const promise = axios.post(URL, {
            name:'Amit',company:'SkillRisers',phone:1111
        });
        promise.then(response=>{
            // Success
        }).catch(err=>{
            // Fail
        }).finally(()=>{
            // Always
        });
    }
    axiosUseWay(){
        const config = {
            method :'post',
            url : '',
            data :{
                'name':'Amit'
            },
            responseType:'json'
        }
        const promise = axios(config);
    }
}