import React from 'react';
import Counter from './components/Counter';
// I am the Root Component
export const App = ()=>{
  const name = 'Amit';
  return (<div>
    <h1 className = ''>Hello React JS {name} </h1>
    <h2>Hi React JS</h2>
    <Counter/>
    </div>);
  // return React.createElement('div',{className:'red'}, React.createElement('h1',null, 'Hello React JS '+name), React.createElement('h2', null, 'Hi React JS'));
 // return React.createElement('h1',{style:{backgroundColor:'red'}},'Hi React JS '+name);
}

//App(); // <App/>
// XML --> Parse React.createElement()