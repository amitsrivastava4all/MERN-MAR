import { useState } from "react";

const Counter = ()=>{
    console.log("Counter App Called...");
    const [count, setCount] = useState(0);
    //let count = 0; // Data
    // Data need to send to the State then it will be re-render
    const plus = ()=>{
        //count++; // Mutable
        setCount(count+1); // Immutable
        //count++;
        //console.log('Plus call ', count);
    }
    const minus = ()=>{
       count--;
        console.log('Minus call ', count);
    }
    return (<div>
        <h1>Count Value is {count}</h1>
        <button onClick={plus}>+</button> &nbsp;
        <button onClick = {minus}>-</button>
    </div>)
}
export default Counter;