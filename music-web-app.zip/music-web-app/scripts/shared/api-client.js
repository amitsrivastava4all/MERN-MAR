import { URLS } from "./config"

export const apiClient = {
    get(){
        fetch(URLS.ARTISTS);
    },
    post(){

    },
    put(){

    },
    delete(){
        
    }
}