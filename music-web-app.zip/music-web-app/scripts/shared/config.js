export const URLS = {
    ARTISTS : 'https://raw.githubusercontent.com/brainmentorspvtltd/myserverdata/master/singers.json'
}