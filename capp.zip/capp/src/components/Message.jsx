import React from 'react'
import { useSelector } from 'react-redux'

const Message = ({msg, type}) => {
    const countReducer = useSelector(state=>state.counterReducer);
    console.log('App State is ', countReducer);
  return (
   <h2>{msg} {type==='title'?'':countReducer.count}</h2>
  )
}

export default Message