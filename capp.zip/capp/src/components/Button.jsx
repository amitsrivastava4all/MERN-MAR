import React from 'react'
import { minus, plus } from '../redux/counter-slice'
import {useDispatch} from 'react-redux';
export const Button = ({value}) => {
    const dispatch = useDispatch();
    const clicked =()=>{
        console.log('Value  ',value );
        if(value =='+'){
            dispatch(plus(1));
        }
        else{
            dispatch(minus(-1));
        }
    }
  return (
    <button onClick={clicked} className='btn btn-primary'>{value}</button>
  )
}
