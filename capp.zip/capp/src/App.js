import logo from './logo.svg';
import './App.css';
import { CounterPage } from './pages/CounterPage';

function App() {
  return (
    <CounterPage/>
  );
}

export default App;
