import React from 'react'
import Message from '../components/Message'
import { Button } from '../components/Button'

export const CounterPage = () => {
  return (
    <div className = 'container'>
           <Message msg = "Counter App" type='title'/>
           <Message msg = "Counter Value is "/>
           <Button value="+"/> &nbsp;
           <Button value="-"/> 
    </div>
  )
}
