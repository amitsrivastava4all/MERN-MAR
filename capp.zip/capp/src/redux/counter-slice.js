import { createSlice } from "@reduxjs/toolkit";

const counterSlice = createSlice({
    name:'counterSlice',
    initialState:{count:0},
    reducers:{
        plus(state, action){
            const val = action.payload;
            state.count = val + state.count;
        },
        minus(state, action){
            const val = action.payload;
            state.count = state.count + val ;
        }
    }
});
export const {plus, minus} = counterSlice.actions;
export default counterSlice.reducer;