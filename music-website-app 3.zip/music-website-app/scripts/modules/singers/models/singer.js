class Singer{
    constructor(name, photo){
        this.name = name;
        this.url = photo;
    }
}
export default Singer;