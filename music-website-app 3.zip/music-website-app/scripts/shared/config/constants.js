export const URLS = {
    SINGER_URL : 'https://raw.githubusercontent.com/brainmentorspvtltd/myserverdata/master/singers.json',
    SONGS_URL :' https://itunes.apple.com/search?'
}