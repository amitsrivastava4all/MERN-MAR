import logo from './logo.svg';
import './App.css';
import { NewsPage } from './pages/NewsPage';

function App() {
  return (
    <NewsPage/>
  );
}

export default App;
