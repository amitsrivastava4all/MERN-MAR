import { News } from "../components/News"
import { Header } from "../shared/components/Header"

export const NewsPage = ()=>{
    return (<div className = 'container'>
        <Header/>
        <News/>
    </div>)
}