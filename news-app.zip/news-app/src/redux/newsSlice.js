import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import { getNewsData } from "../shared/services/api-client";
// Async Call
export const getNews = createAsyncThunk('/news-api-call',async ()=>{
    console.log('Inside get News Thunk');
    const result = await getNewsData();
    
    return result;
})
const newsSlice = createSlice({
    name:'newsSlice',
    initialState:{news:[], loading:false, error:null},
    reducers:{
        // Sync
    },
    extraReducers:
        (builder)=>{
            builder.addCase(getNews.pending,(state, action)=>{
                state.loading = true;
            }).addCase(getNews.fulfilled,(state, action)=>{
                state.loading = false;
                state.news = action.payload;
            }).addCase(getNews.rejected, (state, action)=>{
                state.loading = false;
                state.news = [];
                state.error = action.payload;
            })
            // Async Status --> State Update --> UI
        }
        
    

});
export default newsSlice.reducer;