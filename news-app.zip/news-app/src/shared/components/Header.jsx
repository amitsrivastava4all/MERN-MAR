import React from 'react'

export const Header = () => {
  return (
    <h1 className='alert alert-info'>News App</h1>
  )
}
