import axios from 'axios';
export const getNewsData = async ()=>{
    try{
    const response = await axios.get(process.env.REACT_APP_URL);
    console.log('Response ', response.data);
    return response.data;
    }
    catch(err){
        throw err;
    }
}