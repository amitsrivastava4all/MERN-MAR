import React, { useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { getNews } from '../redux/newsSlice';
import { SingleNews } from './SingleNews';

export const News = () => {
  const dispatch = useDispatch();
  const newsState = useSelector((state)=>{
    console.log('****State is ', state);
    return state;
  });
  useEffect(()=>{
    dispatch(getNews());
    // Mount - [] + no fn return 
    // no [] no fn return - update
    // Fn return + [] = UnMount 
  },[])
  return (
    <div class="row">
    
      {newsState.loading?<p>News Loading.....</p>:<p>News are</p>}
      {newsState.news.sources &&  newsState.news.sources.map(single=><SingleNews currentNews={single}/>)}
      </div>
    )
}
