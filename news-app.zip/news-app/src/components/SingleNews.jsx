import React from 'react'

export const SingleNews = ({currentNews}) => {
    const myStyle = {"width": "18rem"};
  return (
    <div className = 'col-4'>
    <div>
        <div class="card" style={myStyle}>
  <img src='https://static.toiimg.com/photo/msid-95698325/95698325.jpg' class="card-img-top" alt="..."/>
  <div class="card-body">
    <h5 class="card-title">{currentNews.name}</h5>
    <p class="card-text">{currentNews.description}</p>
    <a href={currentNews.url} class="btn btn-primary">Read more</a>
  </div>
</div>
    </div>
    </div>
  )
}
