import logo from './logo.svg';
import './App.css';
import { Ide } from './components/Ide';

function App() {
  return (
    <Ide/>
  );
}

export default App;
