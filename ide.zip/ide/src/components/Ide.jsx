import React from 'react'
import Container from '@mui/material/Container';
import Grid from '@mui/material/Grid';
import Editor from '@monaco-editor/react';
import { Typography } from '@mui/material';
export const Ide = () => {
    // Axios 
    const problemStatement = ` Given a signed 32-bit integer x, return x with its digits 
    reversed. If reversing x causes the value to go outside 
    the signed 32-bit integer range [-231, 231 - 1], 
    then return 0.`;
    const skeletonCode = `class Solution{
        public int primeNumber(int num){
            // Write Your Solution Here
            return 0;
        }
    }
    `;
  return (
    <Container>
        <Grid container rowSpacing={4} columnSpacing={4}>
            <Grid item xs={6}>
                <Typography>
                    {problemStatement}
                </Typography>
            </Grid>
            <Grid item xs={6}>
            <Editor
            height="90vh"
        defaultLanguage="java"
        defaultValue={skeletonCode}
        
      />
            </Grid>
        </Grid>
    </Container>
  )
}
