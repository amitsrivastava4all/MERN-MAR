export const Text = (props)=>{
    return (<h2>{props.msg} {props.val} </h2>)
}