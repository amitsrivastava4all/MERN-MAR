import { useState } from "react";
import { Search } from "../components/Search"
import { Songs } from "../components/Songs";
import { getSongs } from "../services/api-client";

export const SearchPage = ()=>{
    const [allSongs, setSongs]  = useState([]);
    const getArtistName  = async (artistName)=>{
        console.log('Rec Artist Name ', artistName);
        setSongs( await getSongs(artistName));
    }
    return (
        <div className="container">
            <h1 className="alert alert-info text-center">Music Store</h1>
        <Search fn = {getArtistName}/>
        <Songs allsongs = {allSongs}/>
    </div>);
}