import logo from './logo.svg';
import './App.css';
import { SearchPage } from './pages/SearchPage';

function App() {
  return (
    <SearchPage/>
  );
}

export default App;
