export const Song = ({song})=>{
    console.log(song);
    return (<div className="row">
        <div className="col-4">
            <img src = {song.artworkUrl100}/>
        </div>
        <div className="col-4">
        {song.artistName} {song.trackName}
        </div>
        <div className="col-4">
            <button>Play Song</button>
        </div>
        
    </div>)
}