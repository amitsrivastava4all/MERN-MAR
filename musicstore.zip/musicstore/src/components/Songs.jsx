import { Song } from "./Song"

export const Songs =({allsongs})=>{
    console.log('*******All Songs ', allsongs);
    // map (JS)
    // allsongs (data) ---> convert --> JSX
    return (<>
            {allsongs.map((currentSong,index)=><Song key={index} song = {currentSong}/>)}
    </>)
}