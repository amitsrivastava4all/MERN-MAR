import { useState } from "react";

export const useCount = ()=>{
    const [count, setCount] = useState(0); // Predefine
    const plus = ()=>{
        setCount(count+1);
        console.log('I am the Plus Function...');
    }
    return {count, plus};
}