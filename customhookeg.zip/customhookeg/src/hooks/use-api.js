import { useState } from "react";

export const useApi = (URL)=>{
    //const URL = 'https://api.currencyapi.com/v3/latest?base_currency=USD&currencies=INR&apikey=UVbQVkWQGAhQH2V9SWMIJcMvynaiWDUrUvOgwyMj';
    const [data , setData ]  = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError]  = useState(null);
    const fetchData = async ()=>{
        try{
        const response = await fetch(URL);
        const jsonData = await response.json();
        //throw new Error('Some ISsue.....');
        setLoading(false);
        setData(jsonData);
        }
        catch(err){
            setError(err);
        }
    }
    return {data, fetchData, loading, error};
}