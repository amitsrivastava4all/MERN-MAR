import { useEffect } from "react"
import { useApi } from "../hooks/use-api";

export const Rate = ()=>{
    const URL = 'https://api.currencyapi.com/v3/latest?base_currency=USD&currencies=INR&apikey=UVbQVkWQGAhQH2V9SWMIJcMvynaiWDUrUvOgwyMj';
    const {data, loading, error, fetchData} = useApi(URL);
    useEffect(()=>{
        fetchData();
    },[]);
    return (
    <div>
        {error && <p>Something Went Wrong...</p>}
        {loading?<p>Loading....</p>:<h2>Current Rate of USD in INR {data?data.data.INR.value:'0.0'} </h2>
    }
    </div>)
    
}