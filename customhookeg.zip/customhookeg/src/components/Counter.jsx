import { useCount } from "../hooks/use-count"

export const Counter = ()=>{
    const {count, plus} = useCount();
    return (<div>
        <h1> Counter Value is {count}</h1>
        <button onClick = {plus}>Count</button>
    </div>)
}