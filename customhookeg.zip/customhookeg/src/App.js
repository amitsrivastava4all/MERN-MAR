import logo from './logo.svg';
import './App.css';
import { Counter } from './components/Counter';
import { Rate } from './components/Rate';

function App() {
  return (
   <Rate/>
  );
}

export default App;
