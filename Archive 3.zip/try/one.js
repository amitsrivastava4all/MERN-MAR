console.log('Get Load...');
module.exports = {
    show(){
        console.log("I am Show");
    }
}