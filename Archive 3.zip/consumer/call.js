const r = require('../codes2');
r.fn();
r.fn2();