console.log(global);

setTimeout(()=>{
    console.log('Timeout');
},2000);