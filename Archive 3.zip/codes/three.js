console.log("I am Three....");
const t = require('./two');
module.exports={
    disp(){
        t.show();
        console.log("i am Three show...");
    }
}