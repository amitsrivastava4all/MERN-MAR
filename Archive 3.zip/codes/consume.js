const consume = require('./ex');
consume.show();
consume.disp();