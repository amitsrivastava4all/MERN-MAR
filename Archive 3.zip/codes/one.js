console.log('Fn Arguments ', arguments.length);
console.log(arguments[0]);
console.log(arguments[5]);


