// module.exports = {
//     show(){
//         console.log("I am the show");
//     }
// }
// const obj = {

// }
exports = {
    disp(){
        console.log("I am the Disp");
    },
    show(){
        console.log("I am the show")
    }
    
}
module.exports = exports;