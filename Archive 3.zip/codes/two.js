console.log("I am Two....");
module.exports={
    show(){
        console.log("i am two show...");
    }
}