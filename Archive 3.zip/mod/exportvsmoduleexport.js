console.log(module.exports);
console.log(exports);
console.log(module.exports === exports);
exports = {
    add(){
        return "I am add";
    }
}

module.exports = exports;