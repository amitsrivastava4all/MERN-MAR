const d = require('./app');
console.log(process.argv[2], process.argv[3]);
function disp(){
console.log("I am the index file...");
d();
}
disp();
module.exports = disp;

