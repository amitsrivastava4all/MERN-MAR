const {show} = require('./one');
const {disp} = require('./two');
module.exports = {
    'fn':show,
    'fn2':disp
}