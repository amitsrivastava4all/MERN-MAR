const obj = require('../try');
obj.show();