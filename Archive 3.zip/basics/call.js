//const fn = require('./two');
const obj = require('./two');
//console.log(fn(10,20));
console.log(obj.add(10,20));
console.log(obj.sub(10,20));