const c = require('../mod');
c();
