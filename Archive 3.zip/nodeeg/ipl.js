const fs = require('fs');
const path = require('path');
const chokidar = require('chokidar');
//const parentDir = __dirname;
const parentDir= path.normalize(__dirname+'/..');
//const fullPath = path.join(parentDir,'score.txt');
const fullPath = path.join(parentDir,'docs','mydoc','score.txt');
//console.log(fullPath);
// fs.watch(__dirname, (evt)=>{
//     console.log("DIR Event Happen ", evt);
// })

chokidar.watch(__dirname).on('all', (event, path) => {
    console.log(event, path);
  });

fs.watchFile(fullPath,(curr , prev)=>{
    console.log('Score Board has been Change...');
    try{
    const result= fs.readFileSync(fullPath);
    console.log('Score is ', result.toString());
    }
    catch(err){
        console.log('Error During Reading Score ', err);
    }
});