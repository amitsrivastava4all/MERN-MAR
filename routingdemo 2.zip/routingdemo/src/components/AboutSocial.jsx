import React from 'react'

export const AboutSocial = () => {
  return (
    <div>AboutSocial</div>
  )
}
