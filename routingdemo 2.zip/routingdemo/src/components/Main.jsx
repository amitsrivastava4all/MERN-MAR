import React from 'react'
import {Route, Routes} from 'react-router-dom';
import { HomeC } from './HomeC';
import { About } from './About';
import { ContactUs } from './ContactUs';
import { News } from './News';
import { Services } from './Services';
import { Error404 } from './Error404';
import { DynamicRoutes } from './DynamicRoutes';
import { AboutCompany } from './AboutCompany';
import { AboutSocial } from './AboutSocial';
export const Main = () => {
  //return (<DynamicRoutes/>);
  return (
    <>
      <Routes>
          <Route path = "/" element= {<HomeC/>} />
          <Route path = "/aboutus" element= {<About/>} >
          <Route path = "about-company" element = {<AboutCompany/>} />
          <Route path = "about-social" element = {<AboutSocial/>} />
            </Route>
          <Route path = "/contactus" element= {<ContactUs/>} />
          <Route path = "/news" element= {<News/>} />
          <Route path = "/services/:servicename/:year" element= {<Services/>} />
          <Route path="*" element={<Error404/>}/>
      </Routes>
    </>
  )
}
