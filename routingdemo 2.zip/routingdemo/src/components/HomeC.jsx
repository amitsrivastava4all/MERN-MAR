import React from 'react'

export const HomeC = () => {
  return (
    <div>HomeC</div>
  )
}
