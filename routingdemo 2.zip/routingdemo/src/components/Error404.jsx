import React from 'react'

export const Error404 = () => {
  return (
    <h1 className='alert alert-danger'>OOPS U Type Something Wrong...</h1>
  )
}
