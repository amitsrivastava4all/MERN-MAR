import React from 'react'
import { NavLink, Outlet, Route, Routes, useNavigate } from 'react-router-dom'
import { AboutCompany } from './AboutCompany';
import { AboutSocial } from './AboutSocial';

export const About = () => {
    const navigate = useNavigate();
  const redirect = ()=>{
    navigate('/contactus', {
        state:{
            name:'Ram',
            age:22
        }
    });
  }  
  return (
    <div>About
      <br/>
        <NavLink to="/aboutus/about-company">About Company </NavLink> &nbsp; &nbsp;
        <NavLink to="/aboutus/about-social">About Social </NavLink>
        <br/>
        <hr/>
        <Outlet/>
        <button onClick={redirect}>Redirect to Contact Us</button>
    </div>

  )
}
