import React from 'react'
import { HomeC } from './HomeC';
import { About } from './About';
import { ContactUs } from './ContactUs';
import { News } from './News';
import { Services } from './Services';
import { Error404 } from './Error404';
import { useRoutes } from 'react-router-dom';

export const DynamicRoutes = () => {
  const arr = [
    {path :"/", element:<HomeC/>},
    {path :"/aboutus", element:<About/>},
    {path :"/contactus", element:<ContactUs/>},
    {path :"/news", element:<News/>},
    {path:"/services/:servicename/:year", element:<Services/>},
    {path:"*", element:<Error404/>}
  ];
  const jsxElements =  useRoutes(arr); // Hook
  return jsxElements;
}
