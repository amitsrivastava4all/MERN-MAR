import React from 'react'

export const AboutCompany = () => {
  return (
    <div>AboutCompany</div>
  )
}
