export const Header = ()=>{
    return (<h1 className='alert alert-info text-center'>SkillRisers</h1>)
}