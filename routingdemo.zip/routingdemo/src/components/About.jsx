import React from 'react'
import { useNavigate } from 'react-router-dom'

export const About = () => {
    const navigate = useNavigate();
  const redirect = ()=>{
    navigate('/contactus', {
        state:{
            name:'Ram',
            age:22
        }
    });
  }  
  return (
    <div>About
        <button onClick={redirect}>Redirect to Contact Us</button>
    </div>

  )
}
