import React from 'react'
import {Route, Routes} from 'react-router-dom';
import { HomeC } from './HomeC';
import { About } from './About';
import { ContactUs } from './ContactUs';
import { News } from './News';
import { Services } from './Services';
import { Error404 } from './Error404';
export const Main = () => {
  return (
    <>
      <Routes>
          <Route path = "/" element= {<HomeC/>} />
          <Route path = "/aboutus" element= {<About/>} />
          <Route path = "/contactus" element= {<ContactUs/>} />
          <Route path = "/news" element= {<News/>} />
          <Route path = "/services/:servicename/:year" element= {<Services/>} />
          <Route path="*" element={<Error404/>}/>
      </Routes>
    </>
  )
}
