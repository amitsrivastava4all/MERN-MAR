import React from 'react'
import { useLocation } from 'react-router-dom'

export const ContactUs = () => {
   const params=  useLocation();
   console.log('Params ', params);
  return (
    <div>ContactUs {params.state.name} {params.state.age}</div>
  )
}
