import React from 'react'
import { useSearchParams } from 'react-router-dom'

export const News = () => {
   const [searchParams] =  useSearchParams();
   //console.log(searchParams.entries());
   let values = '';
   for(let e of searchParams.entries()){
    console.log(e[1]);
    values+= e[1] + " ";
   }
  return (
    <div>News {values}</div>
  )
}
