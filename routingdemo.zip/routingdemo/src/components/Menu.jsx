import React from 'react'
import {NavLink} from 'react-router-dom';
import './Menu.css';
const Menu = () => {
  const myStyle = (isActive)=>{
    return {backgroundColor:isActive?'black':'cyan'};
  }
  return (
    <div>
        <NavLink style = {({isActive})=>myStyle(isActive)} activeClassName="active"  to="/">Home</NavLink>
        <br/>
        <NavLink style = {({isActive})=>myStyle(isActive)} activeClassName="active"  to="/aboutus">About us</NavLink>
        <br/>
        <NavLink style = {({isActive})=>myStyle(isActive)} activeClassName="active"  to="/contactus">Contact us</NavLink>
        <br/>
        <NavLink style = {({isActive})=>myStyle(isActive)} activeClassName="active"  to="/news?type=Business&time=10AM">News</NavLink>
        <br/>
        <NavLink style = {({isActive})=>myStyle(isActive)} activeClassName="active"  to="/services/sports/2023">Services</NavLink>
    </div>
  )
}

export default Menu