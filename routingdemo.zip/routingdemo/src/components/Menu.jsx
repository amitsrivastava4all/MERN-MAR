import React from 'react'
import {NavLink} from 'react-router-dom';
const Menu = () => {
  return (
    <div>
        <NavLink className="nav-link" to="/">Home</NavLink>
        <NavLink className="nav-link" to="/aboutus">About us</NavLink>
        <NavLink className="nav-link" to="/contactus">Contact us</NavLink>
        <NavLink className="nav-link" to="/news?type=Business&time=10AM">News</NavLink>
        <NavLink className="nav-link" to="/services/sports/2023">Services</NavLink>
    </div>
  )
}

export default Menu