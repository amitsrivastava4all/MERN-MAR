import { Header } from "../components/Header"
import { Main } from "../components/Main"
import Menu from "../components/Menu"

export const Home = ()=>{
    return (<div className="container">
        <Header/>
        <div className ='row'>
            <div className='col-3'>
            <Menu/>
            </div>
            <div className = 'col-9'>
                <Main/>
            </div>
        </div>
       
        
    </div>)
}