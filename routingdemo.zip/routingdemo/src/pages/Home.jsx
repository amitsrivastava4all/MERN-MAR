import { useNavigate } from "react-router-dom"
import { Header } from "../components/Header"
import { Main } from "../components/Main"
import Menu from "../components/Menu"

export const Home = ()=>{
    const navigate = useNavigate();
    return (<div className="container">
        <Header/>
        <div className ='row'>
            <div className='col-3'>
            <Menu/>
            </div>
            <div className = 'col-9'>
                <button onClick={()=>{
                   // navigate(-1); // Back 1 Step
                   navigate(2); // 2 Step forward
                }}>Go Back</button>
                <Main/>
            </div>
        </div>
       
        
    </div>)
}