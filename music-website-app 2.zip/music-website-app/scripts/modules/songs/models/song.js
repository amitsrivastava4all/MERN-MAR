export class Song{
    constructor(name, photo,detail , playurl){
        this.name = name;
        this.photo = photo;
        this.detail = detail;
        this.playurl  = playurl;
    }
}