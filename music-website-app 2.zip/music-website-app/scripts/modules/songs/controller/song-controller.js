import { songService } from "../service/songs-service.js";

window.addEventListener('load', showSongs);

async function showSongs(){
    // Get the Singer Name From the QueryString
    const singerName = getDataFromQueryString();
    const songs = await songService.getSongsBySinger(singerName);
    printSongs(songs);
    // Now it call some BackEnd Api Call and get the songs of given singer
    // print the songs on page
    // when we click on song , it play the song
}

function printSongs(songs){
    console.log('All Songs ',songs);
    songs.forEach(singleSongLayout);
}

function createImage(singleSong){
    const img = document.createElement('img');
    img.src = singleSong.photo;
    img.className = 'img-thumbnail';
    return img;
}

function createPTag(txt){
    const pTag = document.createElement('p');
    pTag.innerText = txt;
    return pTag;
}

function singleSongLayout(singleSong){
    console.log('Single Song Layout call');
    const row = document.createElement('div');
    const col4 = document.createElement('div');
    col4.className = 'col-4';
    col4.appendChild(createImage(singleSong));
    const col6 = document.createElement('div');
    col6.className = 'col-6';
    col6.appendChild(createPTag(singleSong.name));
    col6.appendChild(createPTag(singleSong.detail));
    const col2 = document.createElement('div');
    col2.className = 'col-2';
    const iTag = document.createElement('i');
    iTag.className= 'fa-solid fa-play';
    col2.appendChild(iTag);
    row.className = 'row  alert alert-primary';
    row.appendChild(col4);
    row.appendChild(col6);
    row.appendChild(col2);
    const songsDiv = document.querySelector('#songs');
    console.log('SONGS DIV ', songsDiv);
     songsDiv.appendChild(row);
    /*
    <div class="row alert alert-primary">
        
        
        <div class="col-2">
            <i class="fa-solid fa-play"></i>
        </div>
      </div>
    */
}

function getDataFromQueryString(){
    const url = new URLSearchParams(location.href);
    
    
    for(let x of url.entries()){
         const singerName = x[1];
         return singerName;
    }
    
   
}