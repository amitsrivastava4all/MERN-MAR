import logo from './logo.svg';
import './App.css';
import { Calc } from './pages/Calc';

function App() {
  return (
    <div className = 'container'>
    <Calc/>
    </div>
  );
}

export default App;
